--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Conference_db";
--
-- Name: Conference_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Conference_db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE "Conference_db" OWNER TO postgres;

\connect "Conference_db"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "Conference_db"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "Conference_db" IS 'A database concerning a recent networking event in the data space';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: connected; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.connected (
    id1 integer,
    id2 integer
);


ALTER TABLE public.connected OWNER TO postgres;

--
-- Name: wants_to_work_with; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wants_to_work_with (
    id1 integer,
    id2 integer
);


ALTER TABLE public.wants_to_work_with OWNER TO postgres;

--
-- Name: workers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workers (
    id integer NOT NULL,
    name character varying(30),
    company character varying(30)
);


ALTER TABLE public.workers OWNER TO postgres;

--
-- Data for Name: connected; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.connected (id1, id2) FROM stdin;
\.
COPY public.connected (id1, id2) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: wants_to_work_with; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wants_to_work_with (id1, id2) FROM stdin;
\.
COPY public.wants_to_work_with (id1, id2) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: workers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workers (id, name, company) FROM stdin;
\.
COPY public.workers (id, name, company) FROM '$$PATH$$/3328.dat';

--
-- Name: workers workers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_pkey PRIMARY KEY (id);


--
-- Name: connected connected_id1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.connected
    ADD CONSTRAINT connected_id1_fkey FOREIGN KEY (id1) REFERENCES public.workers(id);


--
-- Name: connected connected_id2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.connected
    ADD CONSTRAINT connected_id2_fkey FOREIGN KEY (id2) REFERENCES public.workers(id);


--
-- Name: wants_to_work_with wants_to_work_with_id1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wants_to_work_with
    ADD CONSTRAINT wants_to_work_with_id1_fkey FOREIGN KEY (id1) REFERENCES public.workers(id);


--
-- Name: wants_to_work_with wants_to_work_with_id2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wants_to_work_with
    ADD CONSTRAINT wants_to_work_with_id2_fkey FOREIGN KEY (id2) REFERENCES public.workers(id);


--
-- PostgreSQL database dump complete
--

